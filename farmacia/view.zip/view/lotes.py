from datetime import datetime

from farmacia.views import datosUser
from ..models import Lotes, Productos, Proveedores, Usuarios
from django.shortcuts import get_object_or_404, redirect, render
from django.contrib import messages
from ..utils import admin_required

from django.db.models import Case, When, Value, IntegerField

@admin_required
def listarLotes(request, id):
    producto = Productos.objects.get(pk=id)
    proveedores = Proveedores.objects.filter(estado=1)
    lotes = (
        Lotes.objects
        .exclude(estado=0)
        .filter(productoid = id)
        .select_related('productoid', 'proveedorid')
        .annotate (
            prioridad = Case (
                When(estado=1, then=Value(0)),  
                When(estado=3, then=Value(1)), 
                When(estado=2, then=Value(2)),  
                default=Value(3),       
                output_field=IntegerField()
            )
        )
        .order_by('prioridad', 'loteid')
    )
    user_data = datosUser(request)
    datos = {**user_data, 'lotes': lotes, 'proveedores': proveedores, 'producto': producto}
    return render(request, 'pages/productos/lotes/listarLotes.html', datos)

"""def listarLotes(request, id):
    producto = Productos.objects.get(pk=id)
    proveedores = Proveedores.objects.filter(estado=1)
    lotes = Lotes.objects.exclude(estado=0).select_related('productoid', 'proveedorid')    
    user_data = datosUser(request)
    datos = {**user_data, 'lotes': lotes, 'proveedores': proveedores, 'producto': producto}
    return render(request, 'pages/productos/lotes/listarLotes.html', datos)"""

@admin_required
def agregarLote(request, id):
    producto = Productos.objects.get(pk=id)
    proveedores = Proveedores.objects.filter(estado = 1)
    user_data = datosUser(request)
    datos = {**user_data, 'producto' : producto, 'proveedores' : proveedores}
    
    if request.method == 'POST':
        fechavencimiento = request.POST.get('fechavencimiento')
        preciocompraunitario = request.POST.get('preciocompraunitario')
        precioventa = request.POST.get('precioventa')
        cantidad = request.POST.get('cantidad')
        proveedorid = request.POST.get('proveedorid')
        
        totalStock = int(cantidad) + producto.stock
        producto.stock = totalStock
        
        if precioventa < preciocompraunitario:
            messages.error(request, "Verifique los datos.")
            return redirect('agregar_lote', id=producto.productoid)
    
        if (int(precioventa) <= 0) or (int(preciocompraunitario) <= 0):
            messages.error(request, "Datos Invalidos.")
            return redirect('agregar_lote', id=producto.productoid)
        
        estado = 1
        if Lotes.objects.filter(productoid=producto).exclude(estado=0).exists():
            estado = 3
            pass
        else:
            producto.preciounidad = precioventa
            
        lote = Lotes(
            fecharegistro=datetime.today().date(),
            fechavencimiento=fechavencimiento,
            preciocompraunitario=preciocompraunitario,
            precioventa = precioventa,
            cantidad=cantidad,
            productoid_id=producto.productoid,
            proveedorid_id=proveedorid,
            estado=estado,
            stock=cantidad,
        )
        
        lote.save()
        producto.save()
        messages.success(request, "Lote agregado correctamente!")
        return redirect('listar_producto')
    return render(request, 'pages/productos/lotes/agregarLote.html', datos)

@admin_required
def cerrarLote(request, id):
    lotes = get_object_or_404(Lotes, loteid=id)
    if int(lotes.estado) == 3:
        messages.warning(request, "Lote en espera no se puede cerrar")
        return redirect('listar_lotes', id=lotes.productoid.productoid)
        
    lotes.estado = 2  # Cambia el estado a 2 --> Cerrar el lote
    lotes.save()
    
    messages.success(request, "Lote cerrado correctamente!")
    return redirect('listar_lotes', id=lotes.productoid.productoid)  # Redirige a la lista de lotes del producto

@admin_required
def eliminarLote(request, id):
    lotes = get_object_or_404(Lotes, loteid=id)
    
    if lotes.estado == 2:
        messages.error(request, "No se puede eliminar un lote cerrado.")
        return redirect('listar_lotes', id=lotes.productoid.productoid)
    else:
        lotes.estado = 0  # Cambia el estado a 0 --> Eliminar el lote
        producto = lotes.productoid
        producto.stock -= lotes.cantidad  # Resta la cantidad del lote al stock del producto
        lotes.save()  # Guarda el cambio en el estado del lote
        producto.save()  # Guarda el cambio en el stock del producto

        messages.success(request, "Lote eliminado correctamente!")
        return redirect('listar_lotes', id=producto.productoid)  # Redirige a la lista de lotes del producto